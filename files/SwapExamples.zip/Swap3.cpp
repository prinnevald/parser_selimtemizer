/* Call-by-reference / Pass-by-reference                  */
/* In this C++ example, we successfully swap two integers */

#include <stdio.h>

void swap ( int & a , int & b )
{
  int temp = a    ;
         a = b    ;
         b = temp ;
}

int main ( void )
{
  int i = 3 ;
  int j = 5 ;

  printf( "Before swap: i = %d , j = %d\n" , i , j ) ;

  swap ( i , j ) ;

  printf( "After  swap: i = %d , j = %d\n" , i , j ) ;

  return 0 ;
}
